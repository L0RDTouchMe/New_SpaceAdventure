export interface IHoveredPlanet {
    name: string
    src: string
    isUnlocked: boolean
}