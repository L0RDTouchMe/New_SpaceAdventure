import React, { useState } from 'react';
import styled from 'styled-components';
import HeaderPhys from './headerPhys';
import background_phys from '../../assets/img/backgrounds/background_phys.svg';

const Physic = () => {
    return (
        <Wrapper>
            <Container>
                <HeaderPhys/>
            </Container>
        </Wrapper>
    );
};

export default Physic;


const Wrapper = styled.div`
    width: 100%;
    height: 100vh;
`;

const Container = styled.div`
    background-image: url(${background_phys});
    width: 100%;
    height: 100%;
`;