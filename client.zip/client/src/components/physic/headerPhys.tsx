import React, { useState } from 'react';
import { NavLink } from 'react-router-dom';
import styled from 'styled-components';
import { logo } from '../../assets/img/svgIcons';

const HeaderPhys = () => {
    return (
        <Container>
            <LogoContainer>
                <NavLink to="/main">
                    <Logo src={logo} />
                </NavLink>
            </LogoContainer>
            <NavLink to="/">ДАМОЙ</NavLink>
        </Container>
    );
};

export default HeaderPhys;


const Container = styled.div`
    width: 100%;
    height: 75px;
    position: fixed;
    background: #000000bd;
    backdrop-filter: blur(10px);
    z-index: 99;
`;

const LogoContainer = styled.div`
    width: 170px;
`;

const Logo = styled.img`
    display: block;
    width: 100px;
    height: 86px;
    margin-left: 30px;
    margin-top: 0;
    transition: transform 500ms ease;
    &:hover {
        cursor: pointer;
        transform: scale(1.2);
    }
`;
