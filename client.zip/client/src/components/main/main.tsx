import React, { useState } from 'react';
import styled from 'styled-components';
import background_authorize from '../../assets/img/backgrounds/mainBackground.png';
import { Container } from '../solarSystem/Wrapper/Wrapper';
import Button from '../../assets/uikit/Button';

const Main = () => {
    return (
        <Wrapper>
            <Content>
                <ContainerAstro>
                    <Title>Астрономия</Title>
                    <Text>Астрономия - происходит из двух греческих слов звезда и закон. Сама наука представляет собой изучения о вселенных,  расположениях, структурах, происхождениях и развитиях небесных тел. Но не смотря на глобальность астрономии, все её законы подчиняются одной физике</Text>
                    <Button text="Вперёд к звёздам"/>
                </ContainerAstro>
                <ContainerPhys>
                    <Title>Физика</Title>
                    <Text>Физика - это наука о наиболее общих законах природы, о материи, её структуре, движении и правилах трансформации. Комплекс знаний физики и её законы, лежат в основе всего естествознания и так или иначе затрагивают все науки включая известную астрономию</Text>
                    <Button text="Вперёд к законам"/>
                </ContainerPhys>
            </Content>
        </Wrapper>
    );
};

export default Main;

const Title = styled.h1`
    margin-top: 30px;
    font-size: 45px;
`;

const Text = styled.p`
    margin: 20px auto 20px auto;
    font-size: 25px;
    width: 400px;
`;

const Content = styled.div`
    display: flex;
    flex-direction: row;
    justify-content: space-around;
`;
const ContainerAstro = styled.div`
    text-align: center;
    width: 450px;
    height: 650px;
    background: #000000bd;
    backdrop-filter: blur(10px);
    border-radius: 40px;

    font-family: sans-serif;
`;

const ContainerPhys = styled.div`
    text-align: center;
    width: 450px;
    height: 650px;
    background: #000000bd;
    backdrop-filter: blur(10px);
    border-radius: 40px;

    font-family: sans-serif;
`;

const Wrapper = styled.div`
    width: 100%;
    height: 100vh;
    background-image: url(${background_authorize});
    padding: 100px 0;
`;
