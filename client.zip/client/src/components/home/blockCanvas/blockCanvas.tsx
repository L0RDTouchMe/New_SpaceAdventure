import * as React from "react";
import { Canvas } from "react-three-fiber";
import Planet from "./Planet"
import { Vector3 } from "three";
import { Suspense } from "react";
import styled from 'styled-components';


const BlockCanvas = ({}) => {
  return (
    <Container>
        <Suspense fallback={null}>
        <Canvas camera={{ position: [3, 3, 3] }}>
            <directionalLight color={"#ffffff"} intensity={0.25} position={new Vector3(-1, 1, 1)}/>
            <Planet position={new Vector3(0,0,0)}/>
        </Canvas>
        </Suspense>
    </Container>
  );
};

export default BlockCanvas;

const Container = styled.div`
    width: 100%;
    height: 800px;
`;