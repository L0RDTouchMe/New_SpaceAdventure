import * as React from "react";
import { FC, useRef } from "react";
import { Mesh, Vector3 } from "three";
import { useFrame, useLoader } from "react-three-fiber";
import { TextureLoader } from "three";
import marsTexture from "../../../assets/img/jpgtexture/Mars.jpg"
import earthTexture from "../../../assets/img/jpgtexture/Earth.jpg"
import venusTexture from "../../../assets/img/jpgtexture/Venus.jpg"

interface ComponentPosition {
  position: Vector3;
}

const Planet: FC<ComponentPosition> = ({ position }) => {
  const ref = useRef<Mesh>(null);

  const randTexture = (mars: string, earth: string, upiter: string) => {
    const masiveTexture = [mars,earth,upiter]
    var rand = Math.floor(Math.random() * masiveTexture.length);
    return(masiveTexture[rand]);
  }
  //ТЕКСТУРЫ
  const texturePlanet = useLoader(TextureLoader, randTexture(marsTexture, earthTexture, venusTexture));

  //ВРАЩЕНИЕ
  useFrame(() => {
    if (ref.current) {
      ref.current.rotation.y += 0.003;
    }
  });

  return (
    <mesh position={position} ref={ref}>
      <sphereGeometry args={[2.5, 64, 64]} />
      <meshStandardMaterial map={texturePlanet} />
    </mesh>
  );
};

export default Planet;
