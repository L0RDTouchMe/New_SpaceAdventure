export interface IUserLeaders {
    id: number,
    username: string,
    score: number,

}

export const UserLeaders: IUserLeaders[] = [
    {
        id: 1,
        username: 'nameUser',
        score: 1
    },
    {
        id: 2,
        username: 'nameUser',
        score: 1
    },
    {
        id: 3,
        username: 'nameUser',
        score: 1
    },
    {
        id: 4,
        username: 'nameUser',
        score: 1
    },
    {
        id: 5,
        username: 'nameUser',
        score: 1
    },
    {
        id: 6,
        username: 'nameUser',
        score: 1
    },
    {
        id: 7,
        username: 'nameUser',
        score: 1
    },
    {
        id: 8,
        username: 'nameUser',
        score: 1
    },
    {
        id: 9,
        username: 'nameUser',
        score: 1
    },
    {
        id: 10,
        username: 'nameUser',
        score: 1
    },
    
]
