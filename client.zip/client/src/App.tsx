import React from 'react';
import { Route, Routes } from 'react-router-dom';
import { useAppSelector } from './hooks';
import { getUserInfo } from './redux/ducks/userInfo';
import SolarSystem from './components/solarSystem/SolarSystem';
import Header from './components/header/Header';
import SignIn from './components/signIn/SignIn';
import Home from './components/home/Home';
import Foooter from './components/footer/Footer';
import Settings from './components/settings/Settings';
import PersonalAccount from './components/personalAccount/PersonalAccount';
import MiniGame from './components/minigame/MiniGame';
import Main from './components/main/main';
import Physic from './components/physic/physic';

const App = () => {
    const user = useAppSelector(getUserInfo);
    
    return (
        <>
            {user.userInfo.isAuthorize && (
                <Header balance={user.userInfo.balance} userName={user.userInfo.login} />
            )}
            <Routes>
                <Route
                    path="/"
                    element={user.userInfo.isAuthorize ? <Main /> : <Home />}
                />
                <Route path="/login" element={<SignIn />} />
                <Route path="/main" element={<Main />} />
                <Route path="/phys" element={<Physic />} />
                <Route path="/phys2" element={<SolarSystem />} />
                
                {user.userInfo.isAuthorize && (
                    <>
                        <Route path="/profile" element={<PersonalAccount />} />
                        <Route path="/profile/settings" element={<Settings />} />
                        <Route path="/minigame" element={<MiniGame />} />
                    </> 
                )}
            </Routes>
            <Foooter />
        </>
    );
};

export default App;
