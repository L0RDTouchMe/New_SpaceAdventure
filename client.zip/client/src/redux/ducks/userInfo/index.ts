export { default as UserInfoSlice } from './UsersInfoSlice';
export { getUserInfo } from './selectors';
export { zeroingError, logOut } from './UsersInfoSlice';
export { fetchUpdateCoins, fetchUpdateScore } from './asyncThunk';
