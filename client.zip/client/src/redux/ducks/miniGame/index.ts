export { default as MiniGameSlice } from './MiniGameSlice';
