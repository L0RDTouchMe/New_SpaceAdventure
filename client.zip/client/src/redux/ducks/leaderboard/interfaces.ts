export interface ILeaderBoard {
    id: number;
    userid: string;
    login: string;
    score: number;
}

export interface MyKnownError {
    message: string;
}