export { default as avatar_icon } from './profile.png';
